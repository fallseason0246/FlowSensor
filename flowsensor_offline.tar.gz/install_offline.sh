#!/usr/bin/env bash
# 离线安装 FlowSensor 的 Python 依赖（Raspberry Pi 4，64 位系统）
# 用法：bash install_offline.sh [虚拟环境路径，默认 ~/flowenv]
set -euo pipefail
cd "$(dirname "$0")"

VENV="${1:-$HOME/flowenv}"
ARCH="$(uname -m)"
PYV="$(python3 -c 'import sys; print(f"{sys.version_info[0]}{sys.version_info[1]}")')"
WHEELS="wheels-py${PYV}-${ARCH}"

echo "系统：${ARCH}，Python ${PYV:0:1}.${PYV:1}"
if [ ! -d "$WHEELS" ]; then
  echo "错误：没有找到 ${WHEELS}/。"
  echo "当前只准备了：$(ls -d wheels-* | tr '\n' ' ')"
  echo "（armv7l 表示 32 位系统，需要另外下载 32 位的包）"
  exit 1
fi

if python3 -m venv "$VENV" 2>/dev/null; then
  # shellcheck disable=SC1091
  source "$VENV/bin/activate"
  pip install --no-index --find-links "$WHEELS" -r requirements.txt
  echo
  echo "装好了。每次开新终端先执行：source $VENV/bin/activate"
else
  echo "python3-venv 不可用，改为装到当前用户目录（~/.local）"
  python3 -m pip install --user --break-system-packages \
    --no-index --find-links "$WHEELS" -r requirements.txt
fi

python3 -c "import gpiod, numpy, matplotlib; print('gpiod', gpiod.__version__, '| numpy', numpy.__version__, '| matplotlib', matplotlib.__version__)"
